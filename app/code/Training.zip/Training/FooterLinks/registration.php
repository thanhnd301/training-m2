<?php
/**
 * Created by PhpStorm.
 * User: smart
 * Date: 8/29/2016
 * Time: 3:54 PM
 */

use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE,'Training_FooterLinks',__DIR__);
