<?php
/**
 * Created by PhpStorm.
 * User: smart
 * Date: 9/13/2016
 * Time: 2:33 PM
 */

namespace Training\SliderWidget\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

class SliderActions extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $item[$this->getData('name')]['edit'] = [
                    'href' => $this->urlBuilder->getUrl(
                        'sliderwidget/slider/edit',
                        [
                            'id' => $item['slider_id']
                        ]
                    ),
                    'label' => __('Edit'),
                    'hidden' => false,
                    'target' => '_blank',
                ];
                $item[$this->getData('name')]['manager'] = [
                    'href' => $this->urlBuilder->getUrl(
                        'sliderwidget/banner/index',
                        [
                            'slider' => $item['slider_id']
                        ]
                    ),
                    'label' => __('Banners Manager'),
                    'hidden' => true,
                    'target' => '_blank',
                ];
            }
        }

        return $dataSource;
    }
}