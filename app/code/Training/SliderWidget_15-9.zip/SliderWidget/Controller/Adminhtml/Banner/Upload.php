<?php
/**
 * Created by PhpStorm.
 * User: smart
 * Date: 9/14/2016
 * Time: 4:24 PM
 */

namespace Training\SliderWidget\Controller\Adminhtml\Banner;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Magento\Backend\App\Action;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Backend\App\Action\Context;

class Upload extends Action
{
    protected $_fileUploaderFactory;
    protected $_mediaDirectory;

    public function __construct(
        UploaderFactory $fileUploaderFactory,
        Filesystem $filesystem,
        Context $context
    ) {

        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        parent::__construct($context);
    }

    /**
     * Check admin permissions for this controller
     *
     * @return boolean
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Training_SliderWidget::sliderwidget_slider');
    }

    /**
     * Upload file controller action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/slider.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('Create log');

        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        try{
            $target = $this->_mediaDirectory->getAbsolutePath('slider');
            $logger->info('Target: '.$target);
            /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
            $uploader = $this->_fileUploaderFactory->create(['fileId' => 'file']);
            /** Allowed extension types */
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
            /** rename file name if already exists */
            $uploader->setAllowRenameFiles(true);
            /** upload file in folder "mycustomfolder" */
            $logger->info('create uploader success');
            $logger->info(print_r($uploader));
            $result = $uploader->save($target);
            $logger->info('Save image success');
            if ($result['file']) {
                $this->messageManager->addSuccess(__('File has been successfully uploaded'));
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
            $logger->info($e->getTraceAsString());
        }
        return $this->resultRedirectFactory->create()->setPath(
            '*/*/upload', ['_secure'=>$this->getRequest()->isSecure()]
        );
    }
}